package RandomNumberGuesser;
import java.util.Scanner;

public class RandomNumberGuesser 
{

	public static void main(String args[]) 
	{
		Scanner sc = new Scanner(System.in);
		Scanner keyboard = new Scanner(System.in); 
		int randNum;
		int nextGuess;
		int highGuess;
		int lowGuess;
		String again;
		do
	    {
	       RNG.resetCount();
	       randNum = RNG.rand();
	       highGuess = 100;
	       lowGuess = 1;

	       do
	       {
	           System.out.println("Enter your guess: ");
	           nextGuess = sc.nextInt();
	           
	           if (RNG.inputValidation(nextGuess, lowGuess, highGuess))
	           {
	               if (nextGuess<=randNum && (randNum-nextGuess) < (randNum-lowGuess))
	               {
	                   lowGuess=nextGuess;
	               }
	               if (nextGuess>=randNum && (nextGuess-randNum) < (highGuess-randNum))
	               {
	                   highGuess=nextGuess;
	               }
	    	       if (nextGuess != randNum)
	    	       {
	               System.out.println("Enter your next guess between " +lowGuess+ " and " +highGuess);
	    	       }
	           }
	       } while (nextGuess != randNum);
	      
	       System.out.println("\nNumber of guesses is " +RNG.getCount());
	       System.out.println("Congratulations, you guessed correctly.");
	       System.out.println("Do you want to try again? (yes or no)");
	       again = keyboard.nextLine();  
	       while (!(again.equalsIgnoreCase("yes") || again.equalsIgnoreCase("Yes") || 
					again.equalsIgnoreCase("no") || again.equalsIgnoreCase("No")))
			{
				System.out.println("Please enter a valid answer.");
				System.out.println("Do you want to try again? (yes or no)");
				again = keyboard.nextLine();  //inputting again
			}
	    } while (again.equalsIgnoreCase("yes") || again.equalsIgnoreCase("Yes"));	
		System.out.println("Thanks for playing the Random Number Guesser!");
	}	
}
